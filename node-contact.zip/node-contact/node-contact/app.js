// Import du module express
const express = require('express');
const bodyParser = require('body-parser')

// Instanciation du server
const app = express();

// parse various different custom JSON types as JSON
app.use(bodyParser.json());

// Import du module contactRouter
const contactRouter = require('./routes/contactRoutes');

// UTILISATION DU MODULE router des contacts EN TANT QUE MIDDLEWARE
app.use('/api/contacts', contactRouter);

// Export de app en tant que module JS
module.exports = app;