//Import du module app
const app = require('./app');

// Definition du port d'ecoute
const port = 4500;

// Definion du port d'ecoute du serveur
app.listen(port, () => {
    console.log(`Vos Requetes sont dispo à l'adresse http://localhost:${port}/api/contacts`)
});