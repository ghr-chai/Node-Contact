const connexion = require('../database/dbConnect');
const Contact = require('../models/contactModel');
const ObjectID = require('mongoose').Types.ObjectId

exports.tousLesContacts = function (req, res) {

    Contact.find({}, function (error, contacts) {
        if (error) {
            res
                .status(500)
                .json({
                    "msg": error.message
                });
        }
        res.json(contacts);
    });
};

exports.ajouterUnContact = function (req, res) {
    let newContact = new Contact(req.body);
    newContact.save()
        .then(function (contact) {
            res
            .status(201)
            .json(contact);
        }).catch(error => {
        res
        .status(400)
        .json(error);
    });
}

exports.modifierUnContact = function(req, res) {
// on vérifie si le id est bien un id de mongodb
    if(!ObjectID.isValid(req.params.id))
        return res.status(400).send("ID unknown : " + req.params.id)
    
        const updateRecord = {
            prenom: req.body.prenom,
            age: req.body.age,
            email: req.body.email
        };
    Contact.findByIdAndUpdate(
        req.params.id,
        {$set: updateRecord},
        {new: true},
        (err, docs) => {
            if(!err) res.send(docs);
            else  console.log("Update error: " + err);
        }
    )    
    

    
    // res.json({
    //     "message": `Put d'id ${req.params.id} OK`
    // });
}

exports.rechercherUnContact =  function (req, res) {

    if(!ObjectID.isValid(req.params.id))
        return res.status(400).send("ID unknown : " + req.params.id)
    
        Contact.findById(
            req.params.id,
            (err, docs)=> {
                if(!err) res.send(docs);
                else console.log("Research error: " + err);
            }
        );
    // res.json({
    //     "message": `Get d'id ${req.params.id} OK`
    // });
}


 

exports.supprimerUnContact = function (req, res) {
   
    if(!ObjectID.isValid(req.params.id))
        return res.status(400).send("ID unknown : " + req.params.id)

    Contact.findByIdAndRemove(
        req.params.id,
        (err, docs)=> {
            if(!err) res.send(docs);
            else console.log("Delete error: " + err);
        }
    );
    

    // res.json({
    //     "message": `Delete d'id ${req.params.id} OK`
    // });
}
