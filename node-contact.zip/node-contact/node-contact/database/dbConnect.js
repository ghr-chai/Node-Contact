const mongoose = require('mongoose');

const protocole = "mongodb";
const server = 'localhost:27017';
const database = "ContactDb";
const dbUrl = `${protocole}://${server}/${database}`;

class MongoConnexion {

    constructor() {
        this.connexion();
    }

    connexion = () => {
        mongoose.connect(dbUrl, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useFindAndModify: false,
            useCreateIndex: true
        }).then(r => {
            console.log(`CONNEXION AU SERVER OK`);
        }).catch(e => {
            console.log(`CONNEXION AU SERVER NOK pour cause ${e}`);
        });
    }
}

module.exports = new MongoConnexion();