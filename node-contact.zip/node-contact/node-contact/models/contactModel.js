const mongoose = require('mongoose');
const validator = require('validator');

const Schema = mongoose.Schema;

const ContactSchema = new Schema({
    prenom: {
        type: String,
        required: true,
        length: 20
    },
    age: {
        type: Number,
        min: 18,
        index: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        default: `${this.prenom}@dwwm.fr`,
        validate: (value) => {
            return validator.isEmail(value);
        }
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("Contact", ContactSchema);